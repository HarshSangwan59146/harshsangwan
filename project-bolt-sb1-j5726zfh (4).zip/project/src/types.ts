import { CartItem } from './types';

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  specifications: {
    ingredients: string[];
    benefits: string[];
    usage: string;
    weight: string;
  };
  stock: number;
  rating: number;
  reviews: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface User {
  email: string;
  password: string;
  phone?: string;
  address?: string;
  favorites: number[];
}

export interface Order {
  id: string;
  date: string;
  status: 'Processing' | 'Shipped' | 'Delivered';
  items: CartItem[];
}

export interface PaymentIntent {
  clientSecret: string;
}