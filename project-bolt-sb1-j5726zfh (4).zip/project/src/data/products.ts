import { Product } from '../types';

export const products: Product[] = [
  {
    id: 1,
    name: "Kumkumadi Face Oil",
    description: "Traditional Ayurvedic brightening facial oil with saffron",
    price: 49.99,
    image: "https://rukminim3.flixcart.com/image/850/1000/xif0q/face-treatment/0/4/8/30-kumkumadi-oil-30-ml-kerala-ayurveda-original-imagkf9tx4dhfzge.jpeg?q=90&crop=false",
    category: "Face Care",
    specifications: {
      ingredients: ["Saffron", "Sandalwood", "Sweet Almond Oil", "Lotus Extract"],
      benefits: ["Brightens complexion", "Reduces dark spots", "Even skin tone"],
      usage: "Apply 2-3 drops on clean face before bedtime",
      weight: "30ml"
    },
    stock: 50,
    rating: 4.8,
    reviews: 128
  },
  {
    id: 2,
    name: "Neem & Tulsi Face Pack",
    description: "Purifying face mask for acne-prone skin",
    price: 29.99,
    image: "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?w=800&auto=format&fit=crop",
    category: "Face Care",
    specifications: {
      ingredients: ["Neem", "Tulsi", "Fuller's Earth", "Turmeric"],
      benefits: ["Controls acne", "Purifies skin", "Reduces inflammation"],
      usage: "Mix with rose water and apply for 15 minutes",
      weight: "100g"
    },
    stock: 75,
    rating: 4.6,
    reviews: 95
  },
  {
    id: 3,
    name: "Rose & Honey Body Oil",
    description: "Luxurious body oil for deep moisturization",
    price: 39.99,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfWQeMrljIZTZzv4saCbHs4FHYKhn-_BpqkA&s",
    category: "Body Care",
    specifications: {
      ingredients: ["Rose Essential Oil", "Organic Honey", "Almond Oil", "Vitamin E"],
      benefits: ["Deep hydration", "Improves skin elasticity", "Natural fragrance"],
      usage: "Apply on damp skin after shower",
      weight: "200ml"
    },
    stock: 60,
    rating: 4.7,
    reviews: 156
  },
  {
    id: 4,
    name: "Triphala Hair Oil",
    description: "Traditional hair strengthening oil blend",
    price: 34.99,
    image: "https://manavkhadiherbal.com/cdn/shop/files/DSC_0826copy_870x1131.jpg?v=1694075240",
    category: "Hair Care",
    specifications: {
      ingredients: ["Triphala Extract", "Coconut Oil", "Brahmi", "Bhringraj"],
      benefits: ["Reduces hair fall", "Promotes growth", "Strengthens roots"],
      usage: "Massage into scalp and leave overnight",
      weight: "150ml"
    },
    stock: 45,
    rating: 4.9,
    reviews: 203
  },
  {
    id: 5,
    name: "Ashwagandha Night Cream",
    description: "Rejuvenating night cream for youthful skin",
    price: 45.99,
    image: "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=800&auto=format&fit=crop",
    category: "Face Care",
    specifications: {
      ingredients: ["Ashwagandha", "Shea Butter", "Rosehip Oil", "Vitamin C"],
      benefits: ["Anti-aging", "Skin repair", "Stress relief"],
      usage: "Apply before bedtime after cleansing",
      weight: "50g"
    },
    stock: 55,
    rating: 4.7,
    reviews: 167
  },
  {
    id: 6,
    name: "Aloe Vera Gel",
    description: "Pure aloe vera gel with herbs",
    price: 19.99,
    image: "https://assets.myntassets.com/w_412,q_60,dpr_2,fl_progressive/assets/images/17738534/2023/1/18/da7934c6-7d72-4c51-9c8f-58c033ea2b0a1674038612261-Aryanveda-Set-of-2-Aloevera-Skin-Hydration--Healthy-Scalp-Ge-5.jpg",
    category: "Skin Care",
    specifications: {
      ingredients: ["Aloe Vera", "Tea Tree", "Cucumber Extract", "Vitamin E"],
      benefits: ["Cooling effect", "Moisturizing", "Healing properties"],
      usage: "Apply as needed on face and body",
      weight: "100g"
    },
    stock: 100,
    rating: 4.5,
    reviews: 234
  },
  {
    id: 7,
    name: "Saffron Face Cream",
    description: "Luxury face cream with pure saffron",
    price: 59.99,
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=800&auto=format&fit=crop",
    category: "Face Care",
    specifications: {
      ingredients: ["Saffron", "Rose Water", "Almond Oil", "Natural Peptides"],
      benefits: ["Skin brightening", "Anti-aging", "Even tone"],
      usage: "Apply twice daily on clean face",
      weight: "50g"
    },
    stock: 40,
    rating: 4.8,
    reviews: 189
  },
  {
    id: 8,
    name: "Herbal Hair Mask",
    description: "Deep conditioning hair mask with natural herbs",
    price: 29.99,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTJiQ46aNIABykb2Ql9ugVzr6U4CDZZizVkAw&s",
    category: "Hair Care",
    specifications: {
      ingredients: ["Hibiscus", "Fenugreek", "Amla", "Yogurt Powder"],
      benefits: ["Deep conditioning", "Reduces frizz", "Promotes shine"],
      usage: "Apply on wet hair for 30 minutes",
      weight: "200g"
    },
    stock: 65,
    rating: 4.6,
    reviews: 145
  },
  {
    id: 9,
    name: "Sandalwood Soap",
    description: "Natural handmade soap with pure sandalwood",
    price: 12.99,
    image: "https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?w=800&auto=format&fit=crop",
    category: "Body Care",
    specifications: {
      ingredients: ["Sandalwood", "Coconut Oil", "Glycerin", "Essential Oils"],
      benefits: ["Gentle cleansing", "Natural fragrance", "Skin softening"],
      usage: "Use daily for bathing",
      weight: "100g"
    },
    stock: 120,
    rating: 4.4,
    reviews: 278
  },
  {
    id: 10,
    name: "Vetiver Body Scrub",
    description: "Exfoliating body scrub with vetiver",
    price: 24.99,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwaDxbLBUrE2t-2F5Y_SzKnGaftaLILl21Fg&s",
    category: "Body Care",
    specifications: {
      ingredients: ["Vetiver", "Sea Salt", "Coconut Shell Powder", "Hemp Oil"],
      benefits: ["Gentle exfoliation", "Removes dead skin", "Refreshing"],
      usage: "Use 2-3 times a week while showering",
      weight: "200g"
    },
    stock: 80,
    rating: 4.5,
    reviews: 167
  },
  {
    id: 11,
    name: "Brahmi Hair Serum",
    description: "Advanced hair serum for hair growth",
    price: 39.99,
    image: "https://jatadhariayurveda.com/cdn/shop/files/Hair-Growth-Serum-Advanced-Formula-Jatadhari-Ayurveda.jpg?v=1699131967",
    category: "Hair Care",
    specifications: {
      ingredients: ["Brahmi", "Biotin", "Aloe Vera", "Rosemary Oil"],
      benefits: ["Promotes growth", "Prevents breakage", "Adds shine"],
      usage: "Apply few drops on scalp daily",
      weight: "30ml"
    },
    stock: 70,
    rating: 4.7,
    reviews: 198
  },
  {
    id: 12,
    name: "Rose Water Toner",
    description: "Pure rose water facial toner",
    price: 19.99,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWjiTJ93HgMD1ws6LjsKInrfEi9Ph5WjQuKw&s",
    category: "Face Care",
    specifications: {
      ingredients: ["Damask Rose Water", "Witch Hazel", "Aloe Vera", "Glycerin"],
      benefits: ["Balances pH", "Refreshes skin", "Natural toning"],
      usage: "Spray on face after cleansing",
      weight: "100ml"
    },
    stock: 90,
    rating: 4.6,
    reviews: 223
  },
  {
    id: 13,
    name: "Ayurvedic Hair Growth Oil",
    description: "Traditional blend for hair growth and nourishment",
    price: 44.99,
    image: "https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/24127042/2024/7/31/6c30898a-d1a4-4cf2-947c-f2577c74ed9d1722419213260-WOW-Skin-Science-Rosemary-with-Biotin-Hair-Growth-Oil---200--1.jpg",
    category: "Hair Care",
    specifications: {
      ingredients: ["Bhringraj", "Amla", "Coconut Oil", "Sesame Oil"],
      benefits: ["Promotes hair growth", "Prevents premature graying", "Nourishes scalp"],
      usage: "Massage into scalp 2-3 times per week",
      weight: "200ml"
    },
    stock: 55,
    rating: 4.8,
    reviews: 167
  },
  {
    id: 14,
    name: "Turmeric Face Wash",
    description: "Gentle cleansing face wash with turmeric",
    price: 22.99,
    image: "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?w=800&auto=format&fit=crop",
    category: "Face Care",
    specifications: {
      ingredients: ["Turmeric", "Neem", "Aloe Vera", "Honey"],
      benefits: ["Deep cleansing", "Anti-bacterial", "Brightening"],
      usage: "Use twice daily for best results",
      weight: "120ml"
    },
    stock: 85,
    rating: 4.5,
    reviews: 143
  },
  {
    id: 15,
    name: "Herbal Foot Cream",
    description: "Intensive moisturizing foot cream with herbs",
    price: 18.99,
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=800&auto=format&fit=crop",
    category: "Body Care",
    specifications: {
      ingredients: ["Peppermint", "Tea Tree", "Shea Butter", "Eucalyptus"],
      benefits: ["Deep moisturizing", "Refreshing", "Anti-fungal"],
      usage: "Apply generously before bedtime",
      weight: "100g"
    },
    stock: 70,
    rating: 4.6,
    reviews: 156
  }
];