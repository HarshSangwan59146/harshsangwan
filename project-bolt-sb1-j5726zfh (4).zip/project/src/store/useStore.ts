import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CartItem, User, Order } from '../types';

interface Store {
  cart: CartItem[];
  user: User | null;
  favorites: number[];
  orderHistory: Order[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  setUser: (user: User | null) => void;
  toggleFavorite: (productId: number) => void;
  addOrder: (order: Order) => void;
  total: () => number;
}

export const useStore = create<Store>()(
  persist(
    (set, get) => ({
      cart: [],
      user: null,
      favorites: [],
      orderHistory: [],
      addToCart: (item) => {
        const cart = get().cart;
        const existingItem = cart.find((i) => i.product.id === item.product.id);
        if (existingItem) {
          set({
            cart: cart.map((i) =>
              i.product.id === item.product.id
                ? { ...i, quantity: i.quantity + item.quantity }
                : i
            ),
          });
        } else {
          set({ cart: [...cart, item] });
        }
      },
      removeFromCart: (productId) => {
        set({ cart: get().cart.filter((item) => item.product.id !== productId) });
      },
      updateQuantity: (productId, quantity) => {
        set({
          cart: get().cart.map((item) =>
            item.product.id === productId ? { ...item, quantity } : item
          ),
        });
      },
      clearCart: () => set({ cart: [] }),
      setUser: (user) => set({ user }),
      toggleFavorite: (productId) => {
        const favorites = get().favorites;
        const isFavorite = favorites.includes(productId);
        set({
          favorites: isFavorite
            ? favorites.filter((id) => id !== productId)
            : [...favorites, productId],
        });
      },
      addOrder: (order) => {
        set({ orderHistory: [order, ...get().orderHistory] });
      },
      total: () =>
        get().cart.reduce(
          (sum, item) => sum + item.product.price * item.quantity,
          0
        ),
    }),
    {
      name: 'ayuantra-store',
    }
  )
);