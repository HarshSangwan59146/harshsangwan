import React from 'react';
import { Award, Users, Heart, Leaf } from 'lucide-react';

export default function AboutUs() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100">
      {/* Hero Section */}
      <div className="relative py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-gray-800 mb-6">About Ayuantra</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover the ancient wisdom of Ayurveda through our modern approach to beauty and wellness.
            </p>
          </div>
        </div>
      </div>

      {/* Expert Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="md:flex items-center gap-12">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <img
                src="https://media.licdn.com/dms/image/v2/D4E03AQEXSIANXo_mTQ/profile-displayphoto-shrink_800_800/B4EZSrUN6hG0Ac-/0/1738040992293?e=1750291200&v=beta&t=WC5x5pQ7svSiK3O7BvLQgb0cEnhp6-Jq7u9JpMe_mgU"
                alt="Dr. Harsh Sangwan"
                className="rounded-lg shadow-xl"
              />
            </div>
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold text-gray-800 mb-6">Meet Our Expert</h2>
              <h3 className="text-2xl font-semibold text-green-600 mb-4">Dr. Harsh Sangwan</h3>
              <p className="text-gray-600 mb-6">
                With over 15 years of experience in Ayurvedic medicine and beauty treatments, Dr. Harsh Sangwan leads our team of experts in creating authentic and effective Ayurvedic beauty products. His deep understanding of traditional herbs and modern skincare needs has helped thousands achieve their beauty goals naturally.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-green-50 rounded-lg">
                  <Award className="w-8 h-8 text-green-600 mb-2" />
                  <h4 className="font-semibold">15+ Years Experience</h4>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <Users className="w-8 h-8 text-green-600 mb-2" />
                  <h4 className="font-semibold">10,000+ Happy Customers</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Our Story */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Our Story</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <Leaf className="w-12 h-12 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold mb-4">Natural Ingredients</h3>
              <p className="text-gray-600">
                We source the purest ingredients from trusted suppliers across India, ensuring each product maintains its authentic Ayurvedic properties.
              </p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <Heart className="w-12 h-12 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold mb-4">Made with Love</h3>
              <p className="text-gray-600">
                Each product is crafted with care and attention to detail, following traditional Ayurvedic principles while incorporating modern science.
              </p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <Award className="w-12 h-12 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold mb-4">100% Quality Assured</h3>
              <p className="text-gray-600">
                Our products undergo rigorous testing and quality control to ensure they meet the highest standards of safety and efficacy.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}