import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { products } from '../data/products';
import { ArrowLeft, Check, ShoppingCart, Heart } from 'lucide-react';
import { useStore } from '../store/useStore';
import toast from 'react-hot-toast';

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart, toggleFavorite, favorites } = useStore();
  const product = products.find(p => p.id === Number(id));

  if (!product) {
    return <div>Product not found</div>;
  }

  const handleAddToCart = () => {
    addToCart({ product, quantity: 1 });
    toast.success('Added to cart!');
  };

  const handleBuyNow = () => {
    addToCart({ product, quantity: 1 });
    navigate('/checkout');
  };

  const handleToggleFavorite = () => {
    toggleFavorite(product.id);
    toast.success(favorites.includes(product.id) ? 'Removed from favorites' : 'Added to favorites');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 py-8">
      <div className="max-w-6xl mx-auto px-4">
        <button
          onClick={() => navigate('/products')}
          className="flex items-center text-green-600 hover:text-green-700 mb-6 font-medium"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Products
        </button>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2 relative">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute top-4 right-4">
                <button 
                  onClick={handleToggleFavorite}
                  className="p-2 bg-white rounded-full shadow-md hover:bg-gray-50"
                >
                  <Heart 
                    className={`w-6 h-6 ${
                      favorites.includes(product.id) 
                        ? 'text-red-500 fill-current' 
                        : 'text-gray-600'
                    }`} 
                  />
                </button>
              </div>
            </div>
            <div className="md:w-1/2 p-8">
              <div className="text-sm font-medium text-green-600 mb-2">{product.category}</div>
              <h1 className="text-4xl font-bold text-gray-800 mb-4">{product.name}</h1>
              <p className="text-gray-600 text-lg mb-6">{product.description}</p>
              <p className="text-4xl font-bold text-green-600 mb-8">${product.price}</p>

              <div className="space-y-8">
                <div>
                  <h2 className="text-2xl font-semibold text-gray-800 mb-4">Product Details</h2>
                  <div className="grid gap-6">
                    <div>
                      <h3 className="font-medium text-gray-700 mb-2">Ingredients</h3>
                      <ul className="grid grid-cols-2 gap-2">
                        {product.specifications.ingredients.map((ingredient, index) => (
                          <li key={index} className="flex items-center text-gray-600">
                            <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                            {ingredient}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-medium text-gray-700 mb-2">Benefits</h3>
                      <ul className="space-y-2">
                        {product.specifications.benefits.map((benefit, index) => (
                          <li key={index} className="flex items-center text-gray-600">
                            <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                            {benefit}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-medium text-gray-700 mb-2">How to Use</h3>
                      <p className="text-gray-600">{product.specifications.usage}</p>
                    </div>

                    <div>
                      <h3 className="font-medium text-gray-700 mb-2">Net Weight</h3>
                      <p className="text-gray-600">{product.specifications.weight}</p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={handleAddToCart}
                    className="flex-1 flex items-center justify-center space-x-2 bg-green-100 text-green-600 py-4 px-6 rounded-xl hover:bg-green-200 transition-colors text-lg font-medium"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    <span>Add to Cart</span>
                  </button>
                  <button
                    onClick={handleBuyNow}
                    className="flex-1 bg-green-600 text-white py-4 px-6 rounded-xl hover:bg-green-700 transition-colors text-lg font-medium"
                  >
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}