import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Leaf, Star, Shield, Heart } from 'lucide-react';

export default function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative h-screen">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1617391765934-f7ac7aa648bc?w=1600&auto=format&fit=crop"
            alt="Ayurvedic Products"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-50" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 h-full flex items-center">
          <div className="animate-fade-in-up">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
              Discover Natural Beauty
            </h1>
            <p className="text-xl text-white mb-8 max-w-2xl">
              Experience the ancient wisdom of Ayurveda with our premium collection of natural beauty products.
            </p>
            <button
              onClick={() => navigate('/products')}
              className="bg-green-600 text-white px-8 py-4 rounded-full text-lg font-medium hover:bg-green-700 transform hover:scale-105 transition-all"
            >
              Shop Now
            </button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-green-50">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-16">Why Choose Ayuantra?</h2>
          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow animate-fade-in">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Leaf className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">100% Natural</h3>
              <p className="text-gray-600">Pure ingredients sourced from nature's finest selections.</p>
            </div>
            <div className="text-center p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow animate-fade-in delay-100">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Expert Crafted</h3>
              <p className="text-gray-600">Formulated by Ayurvedic experts with years of experience.</p>
            </div>
            <div className="text-center p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow animate-fade-in delay-200">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Quality Assured</h3>
              <p className="text-gray-600">Rigorous testing ensures the highest quality standards.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Products */}
      <div className="py-24">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-16">Bestsellers</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((index) => (
              <div
                key={index}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all transform hover:-translate-y-2 cursor-pointer"
                onClick={() => navigate(`/product/${index}`)}
              >
                <img
                  src={`https://images.unsplash.com/photo-${index + 1617391765933}-f7ac7aa648bc?w=800&auto=format&fit=crop`}
                  alt="Product"
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Featured Product {index}</h3>
                  <p className="text-gray-600 mb-4">Experience the magic of nature with our bestselling products.</p>
                  <div className="flex items-center justify-between">
                    <span className="text-green-600 font-semibold">$49.99</span>
                    <Heart className="w-6 h-6 text-red-500" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}