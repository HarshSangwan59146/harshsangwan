import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ShoppingCart, Heart, User, LogOut } from 'lucide-react';
import { useStore } from '../store/useStore';

export default function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { cart, favorites, user, setUser } = useStore();

  if (location.pathname === '/login') return null;

  const handleLogout = () => {
    setUser(null);
    navigate('/login');
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <Link to="/" className="text-2xl font-bold text-green-800">
              Ayuantra
            </Link>
            <div className="hidden md:flex space-x-6">
              <Link to="/" className="text-gray-600 hover:text-green-600">Home</Link>
              <Link to="/products" className="text-gray-600 hover:text-green-600">Products</Link>
              <Link to="/about" className="text-gray-600 hover:text-green-600">About</Link>
              <Link to="/contact" className="text-gray-600 hover:text-green-600">Contact</Link>
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <Link to="/favorites" className="relative">
              <Heart className="w-6 h-6 text-gray-600" />
              {favorites.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {favorites.length}
                </span>
              )}
            </Link>
            
            <Link to="/cart" className="relative">
              <ShoppingCart className="w-6 h-6 text-gray-600" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-green-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </Link>
            
            <Link to="/profile" className="flex items-center space-x-2">
              <User className="w-6 h-6 text-gray-600" />
              <span className="text-sm text-gray-600">{user?.email}</span>
            </Link>
            
            <button
              onClick={handleLogout}
              className="flex items-center space-x-1 text-gray-600 hover:text-red-500"
            >
              <LogOut className="w-5 h-5" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}